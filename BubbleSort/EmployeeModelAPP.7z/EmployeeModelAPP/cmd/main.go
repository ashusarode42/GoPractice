package main

import (
	"EmployeeModelAPP/pkg/Router"
	"fmt"
)

func main() {
	fmt.Println("Starting Server.....")
	Router.StartServer()
}
